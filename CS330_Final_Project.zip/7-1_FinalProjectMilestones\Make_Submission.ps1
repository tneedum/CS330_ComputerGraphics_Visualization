$ErrorActionPreference = 'Stop'
$projectRoot = $PSScriptRoot
$exe = Join-Path $projectRoot 'Release\7-1_FinalProjectMilestones.exe'
if (!(Test-Path $exe)) {
    throw 'Build Release x86 in Visual Studio first. The required EXE is missing.'
}
# Refuse to package an executable built before the source or shader changes.
$exeTime = (Get-Item $exe).LastWriteTimeUtc
$inputs = @('Source','shaders','textures','Dependencies\3DShapes','Dependencies\Utilities','7-1_FinalProjectMilestones.vcxproj')
foreach ($inputPath in $inputs) {
    $newer = Get-ChildItem (Join-Path $projectRoot $inputPath) -File -Recurse |
        Where-Object { $_.LastWriteTimeUtc -gt $exeTime }
    if ($newer) { throw 'The EXE is older than the source. Rebuild Release x86 before packaging.' }
}
$staging = Join-Path ([IO.Path]::GetTempPath()) ('CS330_' + [guid]::NewGuid().ToString('N'))
$folder = Join-Path $staging '7-1_FinalProjectMilestones'
New-Item -ItemType Directory -Path $folder | Out-Null
try {
    foreach ($item in @('Source','Dependencies','shaders','textures','Reference_Image.png','TEXTURE_SOURCES.txt','README.txt','Make_Submission.ps1','7-1_FinalProjectMilestones.sln','7-1_FinalProjectMilestones.vcxproj')) {
        Copy-Item (Join-Path $projectRoot $item) $folder -Recurse
    }
    $release = Join-Path $folder 'Release'
    New-Item -ItemType Directory -Path $release | Out-Null
    Copy-Item $exe $release
    foreach ($item in @('glew32.dll','shaders','textures')) {
        $source = Join-Path $projectRoot ('Release\' + $item)
        if (!(Test-Path $source)) { throw ('Missing runtime item: ' + $item + '. Rebuild the project.') }
        Copy-Item $source $release -Recurse
    }
    $zip = Join-Path (Split-Path $projectRoot -Parent) 'CS330_Final_Project.zip'
    Compress-Archive -Path $folder -DestinationPath $zip -Force
    Write-Host ('Created ' + $zip)
    Write-Host 'Submit this ZIP and the separate Design Decisions Word document.'
}
finally { Remove-Item $staging -Recurse -Force }
