CS 330 Final Project - Computer Desk

BUILD AND TEST BEFORE SUBMITTING
This package contains updated source. Build a NEW Windows EXE in Visual Studio.
The old milestone EXE was removed because it does not match the final source.

1. Extract the ZIP first. Do not open the solution inside the ZIP viewer.
2. Open 7-1_FinalProjectMilestones.sln in Visual Studio 2022 (Codio Windows).
3. At the top, select Release and x86 (the project platform is Win32).
4. Select Build > Rebuild Solution. Confirm 0 failed builds.
5. Press Ctrl+F5 to run. Check that the entire desk appears and textures load.
6. Test every control below. Send a screenshot of the scene and build result
   for review before submission.
7. Close the program. To create the submission ZIP, open PowerShell in this
   project folder and run:
   powershell -ExecutionPolicy Bypass -File .\Make_Submission.ps1
   The script uses a process-only setting and does not change system policy.
   It creates CS330_Final_Project.zip beside the project folder, including
   the NEW EXE and its runtime assets. It excludes temporary build files.
8. Submit CS330_Final_Project.zip and CS330_Design_Decisions.docx separately.

CONTROLS
W/S: forward/backward; A/D: left/right
Q/E: move vertically up/down along the world Y axis
Mouse: look around (pitch/yaw)
Mouse wheel: change travel speed (0.5 to 20 units/second)
O: orthographic view; P: perspective view
R: reset camera position, viewing direction, and travel speed
Escape: close the window
O/P change only projection; navigation continues to work in either view.

PROJECT CONTENTS
Source: scene, object construction, shared settings, camera, and entry point
Dependencies: only the shape utilities and libraries required by this project
shaders and textures: runtime assets copied to Release automatically
Reference_Image.png: original desk image extracted from the proposal
TEXTURE_SOURCES.txt: texture credits and licensing URLs
Release (created by a successful build): EXE, glew32.dll, shaders, textures

This is one self-contained project folder, not the entire course folder.
The included Visual Studio configuration uses the supplied Win32 libraries,
C++17, the v143 toolset, and a Windows 10/11 SDK. No external CS330Content
folder is needed. If Visual Studio offers to select an installed SDK, use
an installed Windows 10/11 SDK and keep v143.

PREVIOUS PACKAGE CHECKS (NOT REPEATED FOR THIS CONFIGURATION FIX)
All six C++ translation units passed GCC C++17 syntax checks.
The actual scene and shaders rendered in an OpenGL 4.5 core context with no
OpenGL errors, including perspective, orthographic, and an angled view.
All three texture images are 1024 x 1024 RGB images.
Each separate object is below 1,000 submitted triangles. A conservative count,
including degenerate strip triangles, gives 932 for the mug (largest object).
These checks do not replace the Visual Studio build and Windows control test.

OCTOBER 20 BUILD CONFIGURATION FIX
The Debug configuration previously defined _DEBUG while selecting the release
static runtime (/MT). It now defines NDEBUG, matching /MT and glfw3_mt.lib.
Debug still generates debugger symbols. Release settings and scene code are
unchanged. Both configurations require a fresh Visual Studio Rebuild Solution.
This revision has not been compiled or run with Visual Studio here.
